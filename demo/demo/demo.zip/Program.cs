﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text;
using System.IO;
using Microsoft.Office.Interop.Excel;
using System.Xml;

namespace demo
{
  class Program
  {
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main()
    {
      System.Windows.Forms.Application.EnableVisualStyles();
      System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
      System.Windows.Forms.Application.Run(new Form1());
    }

    public void Runme(String input, String output)
    {
      String excelOut = output;
      System.Diagnostics.Process process = null;
      if (process == null)
      {
        process = new System.Diagnostics.Process();
        webProcess(input, ref process);

        if (process.HasExited)
        {
          ExcelActions xla = new ExcelActions();
          _Workbook wb = xla.GetWorkbook(excelOut);
          _Worksheet ws = xla.SetWorksheetName(excelOut, "sample");
          xla.WriteToXL(ws, 1, 1, "Name");
          xla.WriteToXL(ws, 1, 2, "Review");
          xla.WriteToXL(ws, 1, 3, "Price");

          XmlDocument data = new XmlDocument();
          data.Load(Directory.GetCurrentDirectory() + "\\data.xml");

          XmlNode node = data.DocumentElement.SelectSingleNode("/root");
          int row = 1;
          foreach (XmlNode type in node.ChildNodes)
          {
            row++;
            int col = 1;
            foreach (XmlNode item in type.ChildNodes)
            {
              xla.WriteToXL(ws, row, col, item.InnerText);
              col++;
              xla.QuickSave(excelOut);
            }
            xla.QuickSave(excelOut);
          }
          xla.SaveWorkbook(excelOut);
          xla.CloseXL();
          System.Windows.Forms.Application.Exit();
        }
      }
    }

    public void webProcess(String input, ref System.Diagnostics.Process process)
    {
      System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
      startInfo.FileName = Directory.GetCurrentDirectory() + "\\scrape.py ";
      startInfo.Arguments = "\"" + input + "\"";
      process.StartInfo = startInfo;
      process.Start();
    }
  }
}
